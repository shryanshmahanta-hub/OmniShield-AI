<#
.SYNOPSIS
  Start the OmniShield AI backend + dashboard locally.

.EXAMPLE
  .\run.ps1                 # http://127.0.0.1:8000/demo
  .\run.ps1 -Demo           # DEMO_MODE=true (presentation banner / settings; does not relax authentication)
  .\run.ps1 -Port 9000 -NoBrowser
  .\run.ps1 -KeepRateLimit  # keep RATE_LIMIT_PER_MINUTE from .env instead of disabling it for local use

  If scripts are blocked:  powershell -ExecutionPolicy Bypass -File .\run.ps1
#>
[CmdletBinding()]
param(
    [int]$Port = 8000,
    [string]$ListenAddress = '127.0.0.1',
    [switch]$Demo,
    [switch]$Reload,
    [switch]$NoBrowser,
    [switch]$KeepRateLimit
)

$ErrorActionPreference = 'Stop'
$backend = Join-Path $PSScriptRoot 'omnishield-backend'
$venv = Join-Path $backend '.venv'
$python = if ($IsLinux -or $IsMacOS) { Join-Path $venv 'bin/python' } else { Join-Path $venv 'Scripts\python.exe' }

if (-not (Test-Path $python)) {
    throw "Virtual environment not found. Run  .\train.ps1  first (or  .\train.ps1 -BaselineOnly  to skip PyTorch)."
}

Push-Location $backend
try {
    if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env'; Write-Host 'Created .env from .env.example' }

    # Fail early with a clear message instead of a stack trace.
    # (Windows PowerShell 5.1 turns native stderr into a terminating error under 'Stop', so relax it for this probe.)
    $prevEap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    & $python -c "import fastapi, uvicorn" 2>&1 | Out-Null
    $importExit = $LASTEXITCODE; $ErrorActionPreference = $prevEap
    if ($importExit -ne 0) { throw "Backend packages are missing. Run  .\train.ps1  (or  $python -m pip install -r requirements.txt)." }

    $hasDl = Test-Path 'artifacts\phishing\textcnn\model.pt'
    $hasBase = Test-Path 'artifacts\phishing\baseline\model.json'
    if ($hasDl) { Write-Host 'Model: PyTorch TextCNN found.' -ForegroundColor Green }
    elseif ($hasBase) { Write-Host 'Model: no TextCNN yet - the labelled TF-IDF baseline will answer. Run .\train.ps1 to train the deep model.' -ForegroundColor Yellow }
    else { Write-Warning 'No trained model found. Scans fall back to rules only. Run .\train.ps1.' }

    if (-not $KeepRateLimit) { $env:RATE_LIMIT_PER_MINUTE = '0' }
    if ($Demo) { $env:DEMO_MODE = 'true' }

    $url = "http://${ListenAddress}:$Port/demo"
    Write-Host "Dashboard: $url   API docs: http://${ListenAddress}:$Port/docs   Model info: http://${ListenAddress}:$Port/api/v1/model/info" -ForegroundColor Cyan
    if (-not $NoBrowser) { Start-Job -ScriptBlock { param($u) Start-Sleep -Seconds 3; Start-Process $u } -ArgumentList $url | Out-Null }

    $uvicornArgs = @('-m', 'uvicorn', 'app.main:app', '--host', $ListenAddress, '--port', "$Port")
    if ($Reload) { $uvicornArgs += '--reload' }
    & $python @uvicornArgs
}
finally { Pop-Location; Get-Job | Remove-Job -Force -ErrorAction SilentlyContinue }
