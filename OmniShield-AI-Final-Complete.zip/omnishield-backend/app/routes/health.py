"""Health check endpoint."""

from fastapi import APIRouter
from app.config import get_settings

router = APIRouter(tags=["Health"])


@router.get("/health")
def health_check() -> dict:
    """Return application health status and current storage configuration."""
    settings = get_settings()
    from app.services.phishing_model import get_model_state
    state = get_model_state()
    model = state.get("model")
    return {
        "status": "ok",
        "app": settings.app_name,
        "environment": settings.environment,
        "demo_mode": settings.demo_mode,
        "auth_mode": settings.auth_mode,
        "incident_store": settings.incident_store,
        "local_model": {"status": state.get("status"), "family": getattr(model, "family", None),
                        "name": getattr(model, "model_name", None)},
    }
