"""Dashboard statistics and trained-model information."""
from collections import Counter
from typing import Any, Dict

from fastapi import APIRouter, Depends, Request

from app.config import get_settings
from app.services.auth import owner_from_request
from app.services.incident_store import BaseIncidentStore, get_incident_store
from app.services.phishing_model import model_info

router = APIRouter(prefix="/api/v1", tags=["Dashboard"])


@router.get("/stats")
def dashboard_stats(request: Request, store: BaseIncidentStore = Depends(get_incident_store)) -> Dict[str, Any]:
    """Aggregate scan history for the overview cards (computed from the sanitized audit trail)."""
    owner = owner_from_request(request)
    events = [e for e in store.list_audit_events(limit=1000, offset=0, owner_id=owner) if e.action == "scan_completed"]
    by_module = Counter(e.module for e in events)
    by_risk = Counter(e.risk_level.value for e in events)
    by_verdict = Counter(e.result for e in events)
    flagged = sum(1 for e in events if e.details.get("flagged"))
    scores = [e.risk_score for e in events]
    info = model_info()
    active = info.get("active") or {}
    best_test = None
    if active:
        sub = "textcnn" if active.get("is_deep_learning") else "baseline"
        best_test = (info.get("models", {}).get(sub, {}).get("metrics", {}) or {}).get("test")
    settings = get_settings()
    return {
        "scans_total": len(events),
        "scans_flagged": flagged,
        "flagged_rate": round(flagged / len(events), 4) if events else None,
        "average_risk_score": round(sum(scores) / len(scores), 4) if scores else None,
        "by_module": dict(by_module), "by_risk_level": dict(by_risk), "by_verdict": dict(by_verdict),
        "open_incidents": store.count(owner_id=owner),
        "sample_note": "Computed from the most recent 1,000 retained scan events (message text is never stored).",
        "model": {"status": info.get("status"), "active": active or None,
                  "test_metrics": None if not best_test else {k: best_test[k] for k in ("accuracy", "precision", "recall", "f1", "n")}},
        "demo_mode": settings.demo_mode, "environment": settings.environment,
    }


@router.get("/model/info")
def get_model_info() -> Dict[str, Any]:
    """Model status, provenance (datasets, licenses, preprocessing) and measured evaluation metrics."""
    return model_info()
