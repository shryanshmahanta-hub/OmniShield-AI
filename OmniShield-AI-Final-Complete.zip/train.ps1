<#
.SYNOPSIS
  Train the OmniShield phishing/spam models (PyTorch TextCNN + TF-IDF baseline) on this machine.

.DESCRIPTION
  1. creates omnishield-backend\.venv (if missing)  2. installs training requirements
  3. downloads the public datasets                  4. trains + evaluates on a held-out test split
  5. prints the results table from artifacts\phishing\MODEL_CARD.md  6. runs the test suite

  Every metric is computed by that run; nothing is hard-coded.

.EXAMPLE
  .\train.ps1                  # full run (needs PyTorch, ~10-30 min on CPU)
  .\train.ps1 -BaselineOnly    # no PyTorch needed, ~10 seconds
  .\train.ps1 -SkipDownload    # datasets already in omnishield-backend\datasets\raw

  If scripts are blocked:  powershell -ExecutionPolicy Bypass -File .\train.ps1
#>
[CmdletBinding()]
param(
    [switch]$BaselineOnly,
    [switch]$SkipDownload,
    [switch]$SkipTests,
    [int]$Epochs = 12
)

$ErrorActionPreference = 'Stop'
$backend = Join-Path $PSScriptRoot 'omnishield-backend'
if (-not (Test-Path $backend)) { throw "Cannot find $backend. Run this script from the project root." }

function Step([string]$Label, [scriptblock]$Block) {
    Write-Host "`n== $Label ==" -ForegroundColor Cyan
    $global:LASTEXITCODE = 0
    & $Block
    if ($LASTEXITCODE -ne 0) { throw "'$Label' failed with exit code $LASTEXITCODE." }
}

$venv = Join-Path $backend '.venv'
$python = if ($IsLinux -or $IsMacOS) { Join-Path $venv 'bin/python' } else { Join-Path $venv 'Scripts\python.exe' }

Step 'Create virtual environment' {
    if (Test-Path $python) { Write-Host 'Already exists.'; return }
    if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 -m venv $venv }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { & python -m venv $venv }
    else { throw 'Python 3.11+ was not found. Install it from https://www.python.org/downloads/ and tick "Add Python to PATH".' }
}

Push-Location $backend
try {
    Step 'Install requirements' {
        & $python -m pip install --upgrade pip
        if ($LASTEXITCODE -ne 0) { return }
        if ($BaselineOnly) {
            & $python -m pip install -r requirements.txt numpy pandas scikit-learn matplotlib
        } else {
            # requirements-train.txt includes torch. If this fails, use Python 3.11/3.12 or see https://pytorch.org/get-started/locally/
            & $python -m pip install -r requirements-train.txt
        }
    }

    if (-not $SkipDownload) {
        # The Hugging Face phishing-email set may be blocked on some networks; the downloader then skips it
        # and prints the manual link. The SMS and Enron sets are enough to train.
        Step 'Download datasets' { & $python scripts/download_datasets.py --all-text }
    }

    $model = if ($BaselineOnly) { 'baseline' } else { 'both' }
    Step "Train ($model, $Epochs epochs)" { & $python scripts/train_model.py --model $model --epochs $Epochs }

    $card = Join-Path $backend 'artifacts\phishing\MODEL_CARD.md'
    if (Test-Path $card) {
        Write-Host "`n== Results (from MODEL_CARD.md) ==" -ForegroundColor Cyan
        $lines = Get-Content $card
        $start = [array]::IndexOf($lines, '## Results (held-out test split)')
        if ($start -ge 0) { $lines[$start..([Math]::Min($start + 8, $lines.Count - 1))] | ForEach-Object { Write-Host $_ } }
        Write-Host "Full report: $card"
    }

    if (-not $SkipTests) { Step 'Run tests' { & $python -m pytest -q } }
}
finally { Pop-Location }

Write-Host "`nDone. Start the app with  .\run.ps1" -ForegroundColor Green
if (-not $BaselineOnly -and -not (Test-Path (Join-Path $backend 'artifacts\phishing\textcnn\model.pt'))) {
    Write-Warning 'No textcnn\model.pt was written - the deep-learning model was not trained (is PyTorch installed?).'
}
