# Deploying the OmniShield AI demo (judges' link)

Recommended: **Hugging Face Spaces (Docker, free "CPU Basic")**. As of this writing a free Space has 2 vCPU, 16 GB RAM and
an ephemeral 50 GB disk, runs the container as UID 1000 and routes traffic to `app_port` (7860). Render's free web
service has far less memory than a PyTorch process comfortably needs. Check both providers' current limits before you rely on this.

## 0. Before you deploy

1. Train locally so the real PyTorch model ships in the image: `.\train.ps1`, then read
   `omnishield-backend\artifacts\phishing\MODEL_CARD.md`.
2. Confirm `omnishield-backend\artifacts\phishing\textcnn\` contains `model.pt`, `config.json`, `vocab.json`.
   Without it the Space still works but answers with the labelled TF-IDF baseline.
3. Test the image locally: `docker build -t omnishield-ai .` then `docker run --rm -p 7860:7860 omnishield-ai`
   and open <http://localhost:7860/demo> -> **Model Metrics**. Active model should read *PyTorch TextCNN*, not *baseline*.
   (`/health` also reports `local_model.family`.)

## 1. Hugging Face Space

1. huggingface.co -> **New Space** -> SDK **Docker** -> blank template -> **CPU basic**, public.
2. Clone it and copy the project in. `Dockerfile` must be at the repository root:

   ```powershell
   git clone https://huggingface.co/spaces/<your-user>/omnishield-ai
   # copy: Dockerfile, .dockerignore, omnishield-backend\, frontend-demo\   (NOT .venv, NOT datasets\raw)
   Copy-Item deploy\huggingface-space-README.md omnishield-ai\README.md      # YAML header: sdk: docker, app_port: 7860
   cd omnishield-ai
   git lfs install; git lfs track "*.pt"                                     # model.pt is >10 MB; skip if the push is accepted without it
   git add .; git commit -m "OmniShield AI demo"; git push
   ```
3. The first build installs CPU PyTorch (several minutes). Watch **Logs**; when it says *Running*, the link is
   `https://<your-user>-omnishield-ai.hf.space/demo`.
4. Free Spaces **sleep after a period of inactivity**; the first visit then takes about a minute. Open the link yourself
   shortly before judging.

## 2. What this configuration does and does not protect

The image defaults (see `Dockerfile`) are for an **intentionally open public demo**:

| Setting | Value | Why |
|---|---|---|
| `ENVIRONMENT` | `demo` | `production` refuses `AUTH_MODE=off` (every `/api` call would return 503). |
| `AUTH_MODE` | `off` | Judges need no token. Anyone with the link can call the API. |
| `TRUST_PROXY_HEADERS` | `true` | Spaces sits behind a proxy; otherwise **all judges share one IP's rate-limit bucket**. Safe only because the proxy is the platform's. |
| `RATE_LIMIT_PER_MINUTE` | `60` | Per client IP. Raise it in the Space's *Variables* if judges hit 429. |
| `INCIDENT_STORE` | `sqlite` in `/app/data` | Resets on restart (ephemeral disk). |

Known consequences, so nothing surprises you on stage:

- **Incidents and the audit log are shared by every visitor** (no per-user owner without auth). They store sanitized
  metadata and findings (which can include suspicious URLs that were scanned), not message bodies, but another judge
  can see them. Don't paste real personal data into the demo.
- No API keys are configured (Web Risk, ClamAV, Rook are off), so URL reputation and virus scanning report "unavailable".
- For anything beyond a demo: set `ENVIRONMENT=production`, `AUTH_MODE=api_key` or `supabase`, and a shared database.

## 3. Variables you may want in the Space (Settings -> Variables)

`RATE_LIMIT_PER_MINUTE`, `DEMO_MODE`, `ENABLE_LOCAL_MODEL`, `ALLOW_BASELINE_FALLBACK`. Never put secrets in Variables;
use **Secrets** (e.g. `API_KEY`, `GOOGLE_WEB_RISK_API_KEY`).

## 4. Smaller image / other hosts

`docker build --build-arg INSTALL_TORCH=0 -t omnishield-ai-lite .` skips PyTorch (baseline only, roughly 1 GB smaller).
The container honours `$PORT`, so Render/Railway/Fly work unchanged; mind their free-tier memory.
