#!/usr/bin/env python3
"""Download the public datasets used to train the OmniShield phishing/spam model.

    python scripts/download_datasets.py --all-text      # SMS + Enron-Spam + Hugging Face phishing e-mail
    python scripts/download_datasets.py --sms --enron   # pick individual sources

Files are written to datasets/raw/ (git-ignored; never bundled). Each source lists mirrors that are tried in
order, because any single host can be unreachable on a given network. A source that cannot be downloaded
is reported and skipped - training simply uses whatever was downloaded and records that in
artifacts/phishing/dataset_report.json. If every mirror fails, download the file manually (URL printed) and
place it at the path shown.

Review each dataset's license and privacy terms (see datasets/README.md) before redistributing anything.
EMBER (PE malware features) is unrelated to phishing text and remains an opt-in extra.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "datasets" / "raw"

SOURCES = {
    "sms": {
        "title": "UCI SMS Spam Collection (5,574 labelled SMS; CC BY 4.0)",
        "dest": ROOT / "sms_spam" / "SMSSpamCollection",
        "mirrors": [
            ("https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip", "zip:SMSSpamCollection"),
            ("https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip", "zip:SMSSpamCollection"),
            # Third-party GitHub copy of the same UCI file (tab-separated label<TAB>text, 5,574 rows).
            ("https://raw.githubusercontent.com/justmarkham/DAT8/master/data/sms.tsv", "raw"),
        ],
        "manual": "https://archive.ics.uci.edu/dataset/228/sms+spam+collection  -> extract 'SMSSpamCollection' to datasets/raw/sms_spam/",
    },
    "enron": {
        "title": "Enron-Spam e-mail corpus (33,716 labelled e-mails; Metsis et al. 2006, CSV conversion GPL-3.0)",
        "dest": ROOT / "enron_spam" / "enron_spam_data.zip",
        "mirrors": [
            ("https://raw.githubusercontent.com/MWiechmann/enron_spam_data/master/enron_spam_data.zip", "raw"),
            ("https://github.com/MWiechmann/enron_spam_data/raw/master/enron_spam_data.zip", "raw"),
        ],
        "manual": "https://github.com/MWiechmann/enron_spam_data -> save enron_spam_data.zip to datasets/raw/enron_spam/",
    },
    "phishing": {
        "title": "Phishing Email Dataset (Hugging Face zefang-liu/phishing-email-dataset; LGPL-3.0 per dataset card)",
        "dest": ROOT / "phishing_email" / "phishing_email.csv",
        "mirrors": [
            ("https://huggingface.co/datasets/zefang-liu/phishing-email-dataset/resolve/main/Phishing_Email.csv", "raw"),
        ],
        "manual": "https://huggingface.co/datasets/zefang-liu/phishing-email-dataset -> save Phishing_Email.csv as datasets/raw/phishing_email/phishing_email.csv",
    },
}
EMBER_URL = "https://ember.elastic.co/ember_dataset_2018_2.tar.bz2"
EMBER_SHA256 = "b6052eb8d350a49a8d5a5396fbe7d16cf42848b86ff969b77464434cf2997812"


def fetch(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "OmniShield-AI-dataset-fetcher/2.0"})
    with urllib.request.urlopen(request, timeout=90) as response, tmp.open("wb") as out:
        shutil.copyfileobj(response, out)
    tmp.replace(dest)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_source(key: str, force: bool = False) -> bool:
    spec = SOURCES[key]
    dest: Path = spec["dest"]
    if dest.exists() and not force:
        print(f"[skip] {spec['title']} already present: {dest}")
        return True
    print(f"[get ] {spec['title']}")
    for url, mode in spec["mirrors"]:
        try:
            print(f"       trying {url}")
            if mode.startswith("zip:"):
                member = mode.split(":", 1)[1]
                archive = dest.parent / "_download.zip"
                fetch(url, archive)
                with zipfile.ZipFile(archive) as zf:
                    names = {Path(n).name: n for n in zf.namelist()}
                    if member not in names:
                        raise ValueError(f"{member} not found in archive")
                    with zf.open(names[member]) as src, dest.open("wb") as out:  # basename only: never trust archive paths
                        shutil.copyfileobj(src, out)
                archive.unlink(missing_ok=True)
            else:
                fetch(url, dest)
            print(f"       saved -> {dest} ({dest.stat().st_size:,} bytes)  sha256={sha256(dest)[:16]}...")
            return True
        except Exception as exc:  # network error, 403, bad archive ...
            print(f"       failed: {type(exc).__name__}: {exc}")
            dest.unlink(missing_ok=True)
    print(f"[FAIL] Could not download automatically. Manual download:\n       {spec['manual']}")
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sms", action="store_true", help="UCI SMS Spam Collection")
    parser.add_argument("--enron", action="store_true", help="Enron-Spam e-mail corpus")
    parser.add_argument("--phishing-email", action="store_true", help="Hugging Face phishing e-mail dataset")
    parser.add_argument("--all-text", "--all-small", dest="all_text", action="store_true", help="All three text datasets")
    parser.add_argument("--force", action="store_true", help="Re-download even if the file exists")
    parser.add_argument("--ember2018", action="store_true", help="(Unrelated to phishing text) large EMBER 2018 PE-feature archive")
    args = parser.parse_args()
    if not (args.sms or args.enron or args.phishing_email or args.all_text or args.ember2018):
        parser.print_help()
        return 0
    ok = []
    if args.sms or args.all_text:
        ok.append(download_source("sms", args.force))
    if args.enron or args.all_text:
        ok.append(download_source("enron", args.force))
    if args.phishing_email or args.all_text:
        ok.append(download_source("phishing", args.force))
    if args.ember2018:
        path = ROOT / "ember" / "ember_dataset_2018_2.tar.bz2"
        if not path.exists():
            print("WARNING: EMBER archive is large; it holds PE feature vectors, not executables.")
            fetch(EMBER_URL, path)
        actual = sha256(path)
        if actual != EMBER_SHA256:
            path.unlink(missing_ok=True)
            raise SystemExit(f"SHA-256 mismatch; deleted archive. Expected {EMBER_SHA256}, got {actual}")
        print(f"EMBER archive SHA-256 verified: {actual}")
    if ok and not any(ok):
        print("\nNo dataset could be downloaded. Training cannot proceed until at least one file is in datasets/raw/.")
        return 1
    if ok and not all(ok):
        print("\nSome sources failed; training will use the ones that were downloaded (recorded in dataset_report.json).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
