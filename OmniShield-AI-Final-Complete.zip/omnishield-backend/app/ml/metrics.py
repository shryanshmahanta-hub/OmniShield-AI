"""Evaluation helpers. Positive class = malicious (1)."""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np


def compute_metrics(y_true: Sequence[int], prob: Sequence[float], threshold: float = 0.5) -> dict:
    """Accuracy / precision / recall / F1 / ROC-AUC and the confusion matrix."""
    from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                                 recall_score, roc_auc_score)
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(prob, dtype=float)
    pred = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    try:
        auc: Optional[float] = float(roc_auc_score(y, p)) if len(set(y.tolist())) == 2 else None
    except ValueError:
        auc = None
    return {
        "n": int(len(y)), "threshold": float(threshold),
        "accuracy": float(accuracy_score(y, pred)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "roc_auc": auc,
        "confusion_matrix": {"labels": ["legitimate", "malicious"], "matrix": [[int(tn), int(fp)], [int(fn), int(tp)]],
                             "layout": "rows = actual, columns = predicted: [[TN, FP], [FN, TP]]"},
    }


def best_f1_threshold(y_true: Sequence[int], prob: Sequence[float]) -> float:
    """Pick the decision threshold on VALIDATION data (never on test data)."""
    from sklearn.metrics import f1_score
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(prob, dtype=float)
    best_t, best_f = 0.5, -1.0
    for t in np.linspace(0.05, 0.95, 91):
        f = f1_score(y, (p >= t).astype(int), zero_division=0)
        if f > best_f + 1e-12:
            best_t, best_f = float(t), float(f)
    return round(best_t, 2)


def per_source_metrics(y_true: Sequence[int], prob: Sequence[float], sources: Sequence[str], threshold: float) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(prob, dtype=float)
    s = np.asarray(sources)
    for name in sorted(set(sources)):
        mask = s == name
        out[name] = compute_metrics(y[mask], p[mask], threshold)
    return out


def metrics_markdown(title: str, m: dict) -> str:
    cm = m["confusion_matrix"]["matrix"]
    auc = "n/a" if m.get("roc_auc") is None else f"{m['roc_auc']:.4f}"
    return (f"### {title}\n\n| Metric | Value |\n|---|---|\n| Samples | {m['n']} |\n| Threshold | {m['threshold']} |\n"
            f"| Accuracy | {m['accuracy']:.4f} |\n| Precision | {m['precision']:.4f} |\n| Recall | {m['recall']:.4f} |\n"
            f"| F1-score | {m['f1']:.4f} |\n| ROC-AUC | {auc} |\n\n"
            f"Confusion matrix (rows = actual, columns = predicted):\n\n| | Pred. legitimate | Pred. malicious |\n|---|---|---|\n"
            f"| **Actual legitimate** | {cm[0][0]} | {cm[0][1]} |\n| **Actual malicious** | {cm[1][0]} | {cm[1][1]} |\n")


def save_confusion_png(m: dict, path, title: str) -> bool:
    """Optional PNG; returns False if matplotlib is not installed."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return False
    cm = np.array(m["confusion_matrix"]["matrix"])
    fig, ax = plt.subplots(figsize=(4.2, 3.8), dpi=130)
    ax.imshow(cm, cmap="Greys")
    ax.set_xticks([0, 1], ["legitimate", "malicious"])
    ax.set_yticks([0, 1], ["legitimate", "malicious"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(title, fontsize=9)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{cm[i, j]}", ha="center", va="center", color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)
    return True
