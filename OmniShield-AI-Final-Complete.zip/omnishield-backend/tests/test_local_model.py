"""Locally trained phishing/spam model: loading, inference, explanations and the API integration.

The suite-wide default is ENABLE_LOCAL_MODEL=false (see conftest.py). Tests here switch it on explicitly by patching
the settings used by ``phishing_model`` / ``text_model``. They accept either backend (PyTorch TextCNN or the TF-IDF
baseline) so they pass both on a machine that has trained the TextCNN and on one that only has the shipped baseline.
"""
import pytest

from app.config import DEFAULT_MODEL_DIR, Settings
from app.services import phishing_model, text_model

SPAM = "URGENT! You have won a 1000 pound cash prize. Call 09061701461 now to claim your reward, claim code KL341. Reply STOP to opt out."
HAM = "Hey, are we still meeting for lunch tomorrow? I'll bring the notes from today's class."


def _settings(**overrides) -> Settings:
    base = dict(environment="test", rate_limit_per_minute=0, incident_store="memory",
                enable_local_model=True, local_model_dir=DEFAULT_MODEL_DIR, allow_baseline_fallback=True)
    base.update(overrides)
    return Settings(**base)


@pytest.fixture
def use_settings(monkeypatch):
    def _apply(settings: Settings):
        monkeypatch.setattr(phishing_model, "get_settings", lambda: settings)
        monkeypatch.setattr(text_model, "get_settings", lambda: settings)
        phishing_model.reset_model_cache()
        return settings
    yield _apply
    phishing_model.reset_model_cache()


@pytest.fixture
def model(use_settings):
    use_settings(_settings())
    m = phishing_model.get_phishing_model()
    if m is None:
        pytest.skip("no trained artifacts in artifacts/phishing (run scripts/train_model.py)")
    return m


def test_model_loads_and_reports_its_family(model):
    assert model.family in {"deep_learning", "classical_baseline"}
    assert 0.0 < model.threshold < 1.0
    state = phishing_model.get_model_state()
    assert state["status"] in {"loaded", "loaded_baseline_fallback"}
    if model.family == "classical_baseline":
        assert state["status"] == "loaded_baseline_fallback", "a baseline must always be labelled as a fallback"


def test_spam_scores_higher_than_ham(model):
    spam = model.analyze(SPAM)
    ham = model.analyze(HAM)
    assert spam["available"] and ham["available"]
    assert spam["probability"] > ham["probability"]
    assert spam["decision"] == "malicious" and spam["prediction"] == "suspicious"
    assert ham["decision"] == "legitimate" and ham["prediction"] == "legitimate"


def test_probability_and_confidence_are_consistent(model):
    for text in (SPAM, HAM):
        res = model.analyze(text)
        assert 0.0 <= res["probability"] <= 1.0
        expected = res["probability"] if res["decision"] == "malicious" else 1.0 - res["probability"]
        assert res["confidence"] == pytest.approx(expected, abs=1e-5)
        assert res["tokens_used"] > 0


def test_explanation_lists_words_that_raise_risk(model):
    explanation = model.analyze(SPAM)["explanation"]
    assert explanation["unit"] == "log-odds change"
    assert explanation["raises_risk"], "a clearly malicious message should have risk-raising words"
    impacts = [row["impact"] for row in explanation["raises_risk"]]
    assert all(i > 0 for i in impacts)
    assert impacts == sorted(impacts, reverse=True)
    assert all(row["impact"] < 0 for row in explanation["lowers_risk"])
    assert all(isinstance(row["token"], str) and row["token"] for row in explanation["raises_risk"])


def test_explanation_can_be_skipped(model):
    assert "explanation" not in model.analyze(SPAM, explain=False)


def test_text_without_usable_tokens_is_not_scored(model):
    res = model.analyze("   ")
    assert res["available"] is False
    assert res["status"] == "no_usable_text"


def test_very_long_input_is_truncated_not_rejected(model):
    res = model.analyze("free prize call now " * 5000)
    assert res["available"] is True
    assert res["tokens_used"] <= model.max_tokens


def test_disabled_model_reports_disabled(use_settings):
    use_settings(_settings(enable_local_model=False))
    res = phishing_model.classify_with_local_model(SPAM)
    assert res["enabled"] is False and res["available"] is False and res["status"] == "disabled"


def test_missing_artifacts_report_not_trained(use_settings, tmp_path):
    use_settings(_settings(local_model_dir=str(tmp_path)))
    state = phishing_model.get_model_state()
    assert state["model"] is None and state["status"] == "not_trained"
    res = phishing_model.classify_with_local_model(SPAM)
    assert res["available"] is False and res["prediction"] is None, "no verdict may be invented without a model"


def test_baseline_fallback_can_be_disabled(use_settings):
    use_settings(_settings(allow_baseline_fallback=False))
    state = phishing_model.get_model_state()
    if state["model"] is not None:
        assert state["model"].family == "deep_learning"
    else:
        assert state["status"] in {"not_trained", "load_failed"}


def test_corrupt_baseline_is_reported_as_load_failed(use_settings, tmp_path):
    (tmp_path / "baseline").mkdir()
    (tmp_path / "baseline" / "model.json").write_text("{ not json", encoding="utf-8")
    use_settings(_settings(local_model_dir=str(tmp_path)))
    state = phishing_model.get_model_state()
    assert state["model"] is None and state["status"] == "load_failed"


def test_model_info_exposes_provenance_and_metrics(use_settings):
    use_settings(_settings())
    info = phishing_model.model_info()
    assert info["status"] in {"loaded", "loaded_baseline_fallback", "not_trained", "load_failed"}
    assert "note" in info and "held-out" in info["note"]
    baseline = info["models"].get("baseline")
    if baseline is not None:
        test = baseline["metrics"]["test"]
        assert test["n"] > 0
        for key in ("accuracy", "precision", "recall", "f1"):
            assert 0.0 <= test[key] <= 1.0
        tn, fp = test["confusion_matrix"]["matrix"][0]
        fn, tp = test["confusion_matrix"]["matrix"][1]
        assert tn + fp + fn + tp == test["n"]


def test_message_endpoint_returns_probability_and_explanation(client, use_settings):
    use_settings(_settings())
    if phishing_model.get_phishing_model() is None:
        pytest.skip("no trained artifacts")
    resp = client.post("/api/v1/scan/message", json={"text": SPAM, "sender": "unknown"})
    assert resp.status_code == 200
    data = resp.json()
    analysis = (data.get("aiAnalysis") or data.get("ai_analysis"))["sms"]
    assert analysis["available"] is True
    assert 0.0 <= analysis["probability"] <= 1.0
    assert analysis["family"] in {"deep_learning", "classical_baseline"}
    assert analysis["explanation"]["raises_risk"]
    assert data["flagged"] is True


def test_email_endpoint_runs_the_local_model_on_subject_and_body(client, use_settings):
    use_settings(_settings())
    if phishing_model.get_phishing_model() is None:
        pytest.skip("no trained artifacts")
    resp = client.post("/api/v1/scan/email", json={"subject": "Lunch tomorrow?", "text": HAM, "sender": "friend@example.invalid", "urls": []})
    assert resp.status_code == 200
    data = resp.json()
    analysis = (data.get("aiAnalysis") or data.get("ai_analysis"))["email"]
    assert analysis["available"] is True and analysis["probability"] < 0.5
    assert data["flagged"] is False
