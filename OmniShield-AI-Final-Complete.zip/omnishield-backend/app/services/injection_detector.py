"""Prompt injection and jailbreak detector for LLM applications."""

import re
import unicodedata
from typing import Any, Dict, List, Optional
from app.services.risk_engine import score_to_risk_level

INJECTION_PATTERNS = [
    (r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+(instructions|directives|rules|prompts)", 0.90, "Override instruction directive"),
    (r"(?i)disregard\s+(all\s+)?(previous|prior|system)\s+(instructions|directives|prompts)", 0.90, "Disregard prompt directive"),
    (r"(?i)you\s+are\s+now\s+(unrestricted|in\s+developer\s+mode|dan|evilbot|jailbroken)", 0.85, "Jailbreak persona adoption (DAN/developer mode)"),
    (r"(?i)from\s+now\s+on\s+you\s+(will|must)\s+(act|pretend|behave)\s+as", 0.70, "Persona hijack attempt"),
    (r"(?i)(repeat|print|reveal|output|display)\s+(the\s+)?(system\s+prompt|above\s+text|initial\s+instructions)", 0.80, "System prompt exfiltration attempt"),
    (r"(?i)<\|im_start\|>|<\|im_end\|>|\[SYSTEM\]|\[INST\]|<system>", 0.85, "Special delimiter token injection"),
    (r"(?i)do\s+anything\s+now|bypass\s+safety\s+filters|jailbreak", 0.80, "Explicit bypass/jailbreak terminology"),
    (r"(?i)base64\s+decode|execute\s+this\s+code\s+silently", 0.65, "Obfuscated payload execution command"),
    # --- Additional patterns (second pass) -------------------------------------------------------
    (r"(?i)ignore\s+(everything|anything)\s+(above|before|you\s+(were|have\s+been)\s+told)|ignore\s+the\s+above\b", 0.85, "Override instruction directive (ignore-above variant)"),
    (r"(?i)forget\s+(everything|all|any(thing)?)\s+(you\s+(were|have\s+been)\s+(told|taught|instructed)|above|before|previous(ly)?|your\s+(instructions|rules|training|guidelines))", 0.85, "Instruction reset ('forget everything') attempt"),
    (r"(?i)(override|bypass|disable|turn\s+off|ignore)\s+(your|the|all)\s+(safety|content|security|ethical)\s+(instructions|rules|guidelines|polic(y|ies)|settings|filters|restrictions)", 0.85, "Safety-policy override attempt"),
    (r"(?i)(pretend|imagine|act\s+as\s+if)\s+(that\s+)?(you\s+(have|had)|there\s+(are|were))\s+no\s+(rules|restrictions|guidelines|filters|limits|limitations)", 0.80, "Rule-free persona request"),
    (r"(?i)act\s+as\s+(an?\s+)?(unrestricted|unfiltered|uncensored|jailbroken)\s+(ai|assistant|model|chatbot)", 0.80, "Unrestricted persona request"),
    (r"(?i)\b(developer|debug|god|sudo|admin(istrator)?)\s+mode\s+(is\s+)?(now\s+)?(enabled|activated|unlocked|engaged)\b", 0.75, "Fake privileged-mode activation"),
    (r"(?i)(your\s+new\s+instructions\s+are|new\s+instructions?\s*:|updated\s+system\s+prompt\s*:)", 0.70, "Instruction replacement attempt"),
    (r"(?i)what\s+(are|were)\s+your\s+(initial|original|hidden|system|secret)\s+(instructions|prompt|rules)|reveal\s+your\s+(hidden|secret|system)\s+(instructions|prompt|rules)", 0.70, "System prompt probing"),
    (r"(?i)<<\s*sys\s*>>|<\|(system|endoftext|assistant)\|>|^\s*#{2,3}\s*(system|instruction)s?\s*:?\s*$", 0.80, "Chat-template delimiter injection"),
    (r"(?i)(do\s+not|don'?t|never)\s+(tell|inform|alert|notify|mention\s+(this\s+)?to)\s+the\s+user|without\s+(telling|informing|alerting|notifying)\s+the\s+user", 0.70, "Concealment from the user (indirect-injection marker)"),
    (r"(?i)(send|forward|email|upload|post|transmit|exfiltrate)\s+(all\s+|every\s+|the\s+|any\s+)?(\w+\s+){0,3}(records|credentials|passwords?|api\s*keys?|secrets?|tokens?|customer\s+data|database|conversation\s+history)\s+to\s+(an?\s+)?(external|outside|remote|unknown|third[- ]party|attacker)|(send|forward|email|upload|post|transmit|exfiltrate)\s+[^.]{0,60}?(records|credentials|passwords?|api\s*keys?|secrets?|tokens?|customer\s+data|conversation\s+history|system\s+prompt)\b[^.]{0,40}?\s+to\s+(\S+@\S+|https?://\S+)", 0.75, "Data exfiltration instruction"),
    (r"(?i)when\s+(the\s+)?(user|assistant|ai)\s+(reads|sees|processes|summari[sz]es)\s+this", 0.60, "Embedded instruction aimed at the reading AI"),
]

# Zero-width / bidi-control characters are used to hide trigger words from naive matching.
_INVISIBLE = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u202a-\u202e\u2066-\u2069]")


def _normalise(text: str) -> tuple[str, bool]:
    """NFKC-fold and strip invisible characters. Returns (clean_text, invisible_chars_were_present)."""
    folded = unicodedata.normalize("NFKC", text)
    stripped = _INVISIBLE.sub("", folded)
    return stripped, stripped != folded


def detect_injection(prompt: str, context: Optional[str] = None) -> Dict[str, Any]:
    """Detect prompt injection and jailbreak attacks in user prompts."""
    full_text, had_invisible = _normalise(f"{context or ''} {prompt}".strip())
    detected_patterns: List[Dict[str, Any]] = []
    max_pattern_score = 0.0

    for pattern, weight, description in INJECTION_PATTERNS:
        match = re.search(pattern, full_text, re.MULTILINE)
        if match:
            detected_patterns.append({
                "description": description,
                "matched_text": match.group(0),
                "weight": weight
            })
            if weight > max_pattern_score:
                max_pattern_score = weight

    # Check for excessive repetition or boundary escapes
    boundary_score = 0.0
    if "---" in full_text and ("system" in full_text.lower() or "assistant" in full_text.lower()):
        boundary_score = 0.40
        detected_patterns.append({
            "description": "System role boundary spoofing attempt",
            "matched_text": "---",
            "weight": 0.40
        })

    # Hidden characters alone are not an attack, but combined with a pattern hit they signal deliberate obfuscation.
    if had_invisible and detected_patterns:
        detected_patterns.append({
            "description": "Invisible/zero-width characters present (possible obfuscation)",
            "matched_text": "[zero-width]",
            "weight": 0.50
        })
        max_pattern_score = max(max_pattern_score, 0.50)

    final_score = max(max_pattern_score, boundary_score)
    normalized_score = round(min(1.0, final_score), 3)
    risk_level = score_to_risk_level(normalized_score)
    flagged = normalized_score >= 0.50

    findings = [p["description"] for p in detected_patterns]
    recommendation = "Prompt is safe to process."
    if flagged:
        recommendation = "Reject or sanitize prompt; direct override of system instructions detected."

    return {
        "risk_score": normalized_score,
        "risk_level": risk_level,
        "flagged": flagged,
        "findings": findings,
        "details": {
            "matches": detected_patterns,
            "patterns_checked": len(INJECTION_PATTERNS),
        },
        "recommendation": recommendation,
    }
