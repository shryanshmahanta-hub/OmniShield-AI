"""Text normalisation, tokenisation and vocabulary shared by training AND inference.

Keeping one implementation guarantees the model sees identical input at train time
and at serve time (train/serve skew is a classic source of silently wrong results).
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter
from typing import Dict, Iterable, List, Sequence

PAD, UNK = "<pad>", "<unk>"
PAD_ID, UNK_ID = 0, 1
MAX_TOKENS_DEFAULT = 256

_HTML_TAG = re.compile(r"<[^>]{1,200}>")
_URL = re.compile(r"(?:https?://|www\.)[^\s<>\"')\]]+", re.I)
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")
_PHONE = re.compile(r"(?<![\w.])(?:\+?\d[\d\s().-]{7,}\d)(?![\w.])")
_NUMBER = re.compile(r"\d+(?:[.,]\d+)*")
# Placeholders, words (with simple apostrophes) and a few punctuation marks that carry
# strong spam/phishing signal. Everything else is dropped.
_TOKEN = re.compile(r"<[a-z]+>|[a-z]+(?:'[a-z]+)?|[!$£€₹%@]")


def normalize_text(text: str) -> str:
    """Lower-case text and replace volatile items with placeholders."""
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = _HTML_TAG.sub(" ", text)
    text = _URL.sub(" <url> ", text)
    text = _EMAIL.sub(" <email> ", text)
    text = _PHONE.sub(" <phone> ", text)
    text = _NUMBER.sub(" <num> ", text)
    return text.lower()


def tokenize(text: str, max_tokens: int = MAX_TOKENS_DEFAULT) -> List[str]:
    """Normalise then split into tokens (first ``max_tokens`` only)."""
    return _TOKEN.findall(normalize_text(text))[:max_tokens]


def tokens_to_text(tokens: Sequence[str]) -> str:
    return " ".join(tokens)


def build_vocab(token_lists: Iterable[Sequence[str]], min_freq: int = 2, max_size: int = 30000) -> Dict[str, int]:
    """Build a token->id map from TRAINING data only (never validation/test)."""
    counts: Counter = Counter()
    for toks in token_lists:
        counts.update(toks)
    vocab: Dict[str, int] = {PAD: PAD_ID, UNK: UNK_ID}
    for tok, freq in counts.most_common():
        if freq < min_freq or len(vocab) >= max_size:
            break
        vocab[tok] = len(vocab)
    return vocab


def encode(tokens: Sequence[str], vocab: Dict[str, int]) -> List[int]:
    return [vocab.get(t, UNK_ID) for t in tokens]
