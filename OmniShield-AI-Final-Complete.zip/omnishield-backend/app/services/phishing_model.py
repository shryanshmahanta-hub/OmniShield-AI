"""Runtime inference for the locally trained OmniShield phishing/spam model.

Loads artifacts written by ``scripts/train_model.py``:
  * ``textcnn/``  - PyTorch deep-learning model (preferred)
  * ``baseline/`` - TF-IDF + logistic regression (non-deep-learning fallback, always labelled as such)

Nothing is downloaded and no scanned text leaves the process. If no artifacts exist the
status is reported honestly (``not_trained``) and no prediction is invented.
"""
from __future__ import annotations

import json
import logging
import math
import threading
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from app.config import get_settings
from app.ml.preprocess import encode, tokenize

logger = logging.getLogger(__name__)

_MAX_OCCLUSION_TOKENS = 120
_LOCK = threading.Lock()
_CACHE: Dict[str, Any] = {}


class PhishingModel:
    """Wraps either backend behind one ``predict_proba_tokens`` interface."""

    def __init__(self, *, family: str, model_name: str, display_name: str, threshold: float, max_tokens: int,
                 score: Callable[[Sequence[Sequence[str]]], List[float]], directory: Path, trained_at: str | None):
        self.family = family
        self.model_name = model_name
        self.display_name = display_name
        self.threshold = float(threshold)
        self.max_tokens = int(max_tokens)
        self._score = score
        self.directory = directory
        self.trained_at = trained_at

    def predict_proba_tokens(self, token_lists: Sequence[Sequence[str]]) -> List[float]:
        return [float(min(1.0, max(0.0, p))) for p in self._score(token_lists)]

    def analyze(self, text: str, explain: bool = True) -> Dict[str, Any]:
        tokens = tokenize(text, self.max_tokens)
        if len(tokens) < 1:
            return {"available": False, "status": "no_usable_text"}
        prob = self.predict_proba_tokens([tokens])[0]
        malicious = prob >= self.threshold
        out: Dict[str, Any] = {
            "available": True, "status": "success", "probability": round(prob, 6),
            "decision": "malicious" if malicious else "legitimate",
            "prediction": "suspicious" if malicious else "legitimate",
            "confidence": round(prob if malicious else 1.0 - prob, 6),
            "threshold": self.threshold, "tokens_used": len(tokens),
            "model": self.model_name, "family": self.family, "display_name": self.display_name,
        }
        if explain:
            out["explanation"] = self.explain_tokens(tokens, prob)
        return out

    def explain_tokens(self, tokens: List[str], base_prob: Optional[float] = None) -> Dict[str, Any]:
        """Leave-one-out occlusion in log-odds space.

        For each token we re-score the message without it; ``impact`` is the drop in the model's log-odds of
        "malicious" (positive = the token pushed the score towards malicious). Log-odds are used because
        probabilities saturate near 0/1 and would hide the contribution of individual words. This is a local
        approximation of the deployed model's behaviour, not a causal proof. Only the first 120 tokens are probed.
        """
        window = tokens[:_MAX_OCCLUSION_TOKENS]
        if base_prob is None:
            base_prob = self.predict_proba_tokens([tokens])[0]
        base_logit = _logit(base_prob)
        variants = [tokens[:i] + tokens[i + 1:] for i in range(len(window))]
        probs = self.predict_proba_tokens(variants) if variants else []
        impact: Dict[str, float] = {}
        for tok, p in zip(window, probs):
            delta = base_logit - _logit(p)
            if tok not in impact or abs(delta) > abs(impact[tok]):
                impact[tok] = delta
        ordered = sorted(impact.items(), key=lambda kv: kv[1], reverse=True)
        raising = [{"token": t, "impact": round(d, 3)} for t, d in ordered if d > 0.02][:8]
        lowering = [{"token": t, "impact": round(d, 3)} for t, d in reversed(ordered) if d < -0.02][:5]
        return {"method": "leave-one-out token occlusion (log-odds)", "unit": "log-odds change",
                "raises_risk": raising, "lowers_risk": lowering,
                "tokens_probed": len(window), "truncated": len(tokens) > len(window)}


def _logit(p: float) -> float:
    p = min(1.0 - 1e-6, max(1e-6, float(p)))
    return math.log(p / (1.0 - p))


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_textcnn(directory: Path) -> PhishingModel:
    from app.ml import torch_model as T  # imports torch; ImportError means PyTorch is not installed
    import torch

    model, config = T.load_model(directory)
    vocab = _read_json(directory / "vocab.json")

    def score(token_lists: Sequence[Sequence[str]]) -> List[float]:
        seqs = [encode(t, vocab) for t in token_lists]
        with torch.inference_mode():
            return [float(x) for x in T.predict_proba(model, seqs)]

    return PhishingModel(family="deep_learning", model_name=config.get("model_name", "omnishield-textcnn"),
                         display_name=config.get("display_name", "PyTorch TextCNN"), threshold=config["threshold"],
                         max_tokens=config.get("max_tokens", 256), score=score, directory=directory,
                         trained_at=config.get("trained_at"))


def _load_baseline(directory: Path) -> PhishingModel:
    from app.ml.linear_model import load_params

    scorer = load_params(directory / "model.json")
    config = _read_json(directory / "config.json")
    return PhishingModel(family="classical_baseline", model_name=config.get("model_name", "omnishield-tfidf-logreg"),
                         display_name=config.get("display_name", "TF-IDF + logistic regression (baseline)"),
                         threshold=config["threshold"], max_tokens=config.get("max_tokens", 256),
                         score=scorer.predict_proba_tokens, directory=directory, trained_at=config.get("trained_at"))


def _load() -> Dict[str, Any]:
    settings = get_settings()
    status: Dict[str, Any] = {"model": None, "status": "disabled", "detail": "ENABLE_LOCAL_MODEL is false", "tried": []}
    if not settings.enable_local_model:
        return status
    root = Path(settings.local_model_dir)
    notes: List[str] = []
    dl_dir = root / "textcnn"
    if (dl_dir / "model.pt").is_file() and (dl_dir / "config.json").is_file():
        try:
            model = _load_textcnn(dl_dir)
            return {"model": model, "status": "loaded", "detail": "PyTorch deep-learning model loaded", "tried": notes}
        except ImportError:
            notes.append("textcnn found but PyTorch is not installed")
        except Exception as exc:  # corrupted / incompatible artifact
            logger.warning("TextCNN artifact could not be loaded: %s", type(exc).__name__)
            notes.append(f"textcnn failed to load ({type(exc).__name__})")
    else:
        notes.append("no trained TextCNN found (run scripts/train_model.py)")
    base_dir = root / "baseline"
    if settings.allow_baseline_fallback and (base_dir / "model.json").is_file():
        try:
            model = _load_baseline(base_dir)
            return {"model": model, "status": "loaded_baseline_fallback",
                    "detail": "Deep-learning model unavailable; using the classical TF-IDF baseline. " + "; ".join(notes),
                    "tried": notes}
        except Exception as exc:
            logger.warning("Baseline artifact could not be loaded: %s", type(exc).__name__)
            notes.append(f"baseline failed to load ({type(exc).__name__})")
    status.update(status="not_trained" if not any("failed" in n or "PyTorch" in n for n in notes) else "load_failed",
                  detail="; ".join(notes) or "no artifacts", tried=notes)
    return status


def get_model_state(force_reload: bool = False) -> Dict[str, Any]:
    key = "state"
    with _LOCK:
        if force_reload or key not in _CACHE:
            _CACHE[key] = _load()
        return _CACHE[key]


def reset_model_cache() -> None:
    with _LOCK:
        _CACHE.clear()


def get_phishing_model() -> Optional[PhishingModel]:
    return get_model_state().get("model")


def classify_with_local_model(text: str) -> Dict[str, Any]:
    """Return a dict compatible with ``text_model.classify_text`` (plus probability/explanation)."""
    settings = get_settings()
    if not settings.enable_local_model:
        return {"enabled": False, "available": False, "model": None, "prediction": None, "confidence": None, "status": "disabled"}
    state = get_model_state()
    model: Optional[PhishingModel] = state.get("model")
    if model is None:
        return {"enabled": True, "available": False, "model": None, "prediction": None, "confidence": None,
                "status": state.get("status", "not_trained")}
    try:
        res = model.analyze(text)
    except Exception as exc:
        logger.warning("Local model inference failed: %s", type(exc).__name__)
        return {"enabled": True, "available": False, "model": model.model_name, "prediction": None, "confidence": None,
                "status": "inference_failed"}
    if not res.get("available"):
        return {"enabled": True, "available": False, "model": model.model_name, "prediction": None, "confidence": None,
                "status": res.get("status", "unavailable")}
    return {"enabled": True, **res}


def load_report(name: str, subdir: str = "") -> Optional[dict]:
    """Read a JSON report (metrics, dataset report) from the artifact directory, if present."""
    path = Path(get_settings().local_model_dir) / subdir / name
    try:
        return _read_json(path) if path.is_file() else None
    except Exception:
        return None


def model_info() -> Dict[str, Any]:
    """Everything the dashboard needs to show model status, provenance and measured metrics."""
    state = get_model_state()
    model: Optional[PhishingModel] = state.get("model")
    active_dir = model.directory.name if model else None
    info: Dict[str, Any] = {
        "status": state.get("status"), "detail": state.get("detail"),
        "active": None if model is None else {
            "name": model.model_name, "display_name": model.display_name, "family": model.family,
            "is_deep_learning": model.family == "deep_learning", "threshold": model.threshold, "trained_at": model.trained_at,
            "artifact": active_dir},
        "dataset_report": load_report("dataset_report.json"),
        "models": {},
        "note": ("All metrics are measured on a held-out test split by scripts/train_model.py. They describe public English SMS/email "
                 "corpora only and do not guarantee performance on other traffic."),
    }
    for sub in ("textcnn", "baseline"):
        rep = load_report("metrics.json", sub)
        if rep:
            info["models"][sub] = rep
    return info
