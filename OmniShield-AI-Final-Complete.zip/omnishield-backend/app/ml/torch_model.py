"""PyTorch TextCNN phishing / spam classifier (trained from scratch, CPU-friendly).

Architecture: token embedding -> parallel 1-D convolutions (kernel sizes 2,3,4,5) ->
masked global max-pooling -> dropout -> 64-unit hidden layer -> 1 logit (malicious).
This module imports PyTorch at import time; import it only where torch is required.
"""
from __future__ import annotations

import copy
import json
import random
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence

import numpy as np
import torch
import torch.nn as nn

from app.ml.preprocess import PAD_ID


class TextCNN(nn.Module):
    def __init__(self, vocab_size: int, embed_dim: int = 100, num_filters: int = 96,
                 kernel_sizes: Sequence[int] = (2, 3, 4, 5), hidden: int = 64, dropout: float = 0.4):
        super().__init__()
        self.kernel_sizes = tuple(int(k) for k in kernel_sizes)
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=PAD_ID)
        self.convs = nn.ModuleList([nn.Conv1d(embed_dim, num_filters, k) for k in self.kernel_sizes])
        self.dropout = nn.Dropout(dropout)
        self.fc1 = nn.Linear(num_filters * len(self.kernel_sizes), hidden)
        self.out = nn.Linear(hidden, 1)

    def forward(self, ids: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
        """ids: (B, L) int64 with L >= max(kernel_sizes); lengths: (B,) true token counts. Returns logits (B,)."""
        x = self.embedding(ids).transpose(1, 2)  # (B, E, L)
        pooled = []
        for conv, k in zip(self.convs, self.kernel_sizes):
            h = torch.relu(conv(x))  # (B, F, L-k+1)
            positions = torch.arange(h.size(2), device=ids.device)[None, :]  # (1, L-k+1)
            valid = positions < (lengths - k + 1).clamp(min=1)[:, None]  # (B, L-k+1); position 0 is always valid
            h = h.masked_fill(~valid[:, None, :], float("-inf"))
            pooled.append(h.max(dim=2).values)  # (B, F)
        feat = self.dropout(torch.cat(pooled, dim=1))
        feat = self.dropout(torch.relu(self.fc1(feat)))
        return self.out(feat).squeeze(1)


def make_batch(seqs: Sequence[Sequence[int]], labels: Optional[Sequence[int]], min_len: int, device="cpu"):
    """Right-pad to the longest sequence in the batch (at least ``min_len``)."""
    lengths = [max(1, len(s)) for s in seqs]
    width = max(max(lengths), min_len)
    arr = np.full((len(seqs), width), PAD_ID, dtype=np.int64)
    for i, s in enumerate(seqs):
        if len(s):
            arr[i, :len(s)] = s
    ids = torch.from_numpy(arr).to(device)
    lens = torch.tensor(lengths, dtype=torch.long, device=device)
    y = None if labels is None else torch.tensor(list(labels), dtype=torch.float32, device=device)
    return ids, lens, y


@torch.no_grad()
def predict_proba(model: TextCNN, seqs: Sequence[Sequence[int]], batch_size: int = 256, device="cpu") -> np.ndarray:
    model.eval()
    min_len = max(model.kernel_sizes)
    out: List[np.ndarray] = []
    for start in range(0, len(seqs), batch_size):
        ids, lens, _ = make_batch(seqs[start:start + batch_size], None, min_len, device)
        out.append(torch.sigmoid(model(ids, lens)).cpu().numpy())
    return np.concatenate(out) if out else np.zeros(0, dtype=np.float32)


def train_textcnn(train_seqs, y_train, val_seqs, y_val, vocab_size: int, *, epochs: int = 12, batch_size: int = 64,
                  lr: float = 2e-3, weight_decay: float = 1e-4, patience: int = 3, seed: int = 42, device: Optional[str] = None,
                  log: Callable[[str], None] = print, **model_kwargs) -> tuple:
    """Train with AdamW + BCE, early-stop on validation loss, return (best model, history)."""
    from sklearn.metrics import f1_score

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    model = TextCNN(vocab_size, **model_kwargs).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    loss_fn = nn.BCEWithLogitsLoss()
    min_len = max(model.kernel_sizes)
    rng = np.random.default_rng(seed)
    y_val_arr = np.asarray(y_val, dtype=np.float32)
    best_loss, best_state, best_epoch, stale = float("inf"), None, 0, 0
    history: List[dict] = []
    log(f"[train] device={device} params={sum(p.numel() for p in model.parameters()):,} train={len(train_seqs)} val={len(val_seqs)}")
    for epoch in range(1, epochs + 1):
        model.train()
        started = time.time()
        order = rng.permutation(len(train_seqs))
        running, seen = 0.0, 0
        for start in range(0, len(order), batch_size):
            idx = order[start:start + batch_size]
            ids, lens, y = make_batch([train_seqs[i] for i in idx], [y_train[i] for i in idx], min_len, device)
            optimizer.zero_grad()
            loss = loss_fn(model(ids, lens), y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            running += float(loss.item()) * len(idx)
            seen += len(idx)
        val_prob = predict_proba(model, val_seqs, device=device)
        eps = 1e-7
        val_loss = float(-np.mean(y_val_arr * np.log(val_prob + eps) + (1 - y_val_arr) * np.log(1 - val_prob + eps)))
        val_f1 = float(f1_score(y_val_arr.astype(int), (val_prob >= 0.5).astype(int), zero_division=0))
        history.append({"epoch": epoch, "train_loss": running / max(1, seen), "val_loss": val_loss, "val_f1_at_0.5": val_f1,
                        "seconds": round(time.time() - started, 1)})
        log(f"[train] epoch {epoch:02d} train_loss={history[-1]['train_loss']:.4f} val_loss={val_loss:.4f} "
            f"val_f1={val_f1:.4f} ({history[-1]['seconds']}s)")
        if val_loss < best_loss - 1e-4:
            best_loss, best_epoch, stale = val_loss, epoch, 0
            best_state = copy.deepcopy({k: v.detach().cpu() for k, v in model.state_dict().items()})
        else:
            stale += 1
            if stale >= patience:
                log(f"[train] early stopping at epoch {epoch} (best epoch {best_epoch})")
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    model.to("cpu")
    return model, {"epochs_run": len(history), "best_epoch": best_epoch, "best_val_loss": best_loss, "history": history}


def save_model(model: TextCNN, directory: Path, config: dict) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), directory / "model.pt")  # plain state_dict: loadable with weights_only=True
    (directory / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")


def load_model(directory: Path) -> tuple:
    """Return (model in eval mode, config). Uses weights_only=True so no pickled code is executed."""
    config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
    model = TextCNN(config["vocab_size"], **config["model_kwargs"])
    state = torch.load(directory / "model.pt", map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()
    return model, config
