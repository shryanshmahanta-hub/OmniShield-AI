// Overwritten at build time on Vercel by build-config.mjs (from the API_BASE_URL env var).
// When served by the FastAPI backend, /config.js is generated from the backend's API_BASE_URL instead.
window.OMNISHIELD_CONFIG = { API_BASE_URL: "" };
