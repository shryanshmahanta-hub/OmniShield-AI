"""Dataset loading, cleaning, de-duplication and stratified splitting.

Label convention everywhere: 1 = malicious (phishing / spam / scam), 0 = legitimate.
Only genuine, publicly sourced corpora are loaded; nothing here synthesises examples.
"""
from __future__ import annotations

import csv
import io
import json
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from app.ml.preprocess import tokenize, tokens_to_text

csv.field_size_limit(min(2**31 - 1, 1 << 30))

# --------------------------------------------------------------------------- sources
SOURCES: Dict[str, Dict[str, str]] = {
    "uci_sms": {
        "title": "SMS Spam Collection v.1 (UCI Machine Learning Repository)",
        "url": "https://archive.ics.uci.edu/dataset/228/sms+spam+collection",
        "license": "CC BY 4.0 (per UCI dataset page)",
        "citation": "Almeida, T.A., Gomez Hidalgo, J.M., Yamakami, A. (2011). Contributions to the study of SMS spam filtering. DocEng '11.",
        "positive_label": "spam (includes smishing/scam texts)",
        "kind": "sms",
    },
    "enron_spam": {
        "title": "Enron-Spam email corpus (Metsis, Androutsopoulos, Paliouras), CSV conversion by M. Wiechmann",
        "url": "https://github.com/MWiechmann/enron_spam_data",
        "license": "Conversion repository: GPL-3.0. Underlying Enron-Spam corpus: public research release (see http://www2.aueb.gr/users/ion/data/enron-spam/). Verify terms before redistribution.",
        "citation": "Metsis, V., Androutsopoulos, I., Paliouras, G. (2006). Spam Filtering with Naive Bayes - Which Naive Bayes? CEAS 2006.",
        "positive_label": "spam (unsolicited/bulk/scam email; NOT exclusively credential phishing)",
        "kind": "email",
    },
    "phishing_email_hf": {
        "title": "Phishing Email Dataset (Hugging Face: zefang-liu/phishing-email-dataset)",
        "url": "https://huggingface.co/datasets/zefang-liu/phishing-email-dataset",
        "license": "Listed on the dataset card as LGPL-3.0; verify the card before redistribution or commercial use.",
        "citation": "Compilation of public phishing / legitimate email corpora; see dataset card for original sources.",
        "positive_label": "Phishing Email",
        "kind": "email",
    },
}

RAW_FILES = {
    "uci_sms": ["sms_spam/SMSSpamCollection", "sms_spam/sms.tsv"],
    "enron_spam": ["enron_spam/enron_spam_data.zip", "enron_spam/enron_spam_data.csv"],
    "phishing_email_hf": ["phishing_email/phishing_email.csv"],
}


@dataclass
class Record:
    text: str
    label: int
    source: str


# --------------------------------------------------------------------------- loaders
def load_uci_sms(path: Path) -> List[Record]:
    """Tab-separated ``label<TAB>text`` file (UCI original file name: SMSSpamCollection)."""
    records: List[Record] = []
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as handle:
        for line in handle:
            line = line.rstrip("\r\n")
            if "\t" not in line:
                continue
            label, text = line.split("\t", 1)
            label = label.strip().lower()
            if label not in {"ham", "spam"}:
                continue
            records.append(Record(text=text, label=1 if label == "spam" else 0, source="uci_sms"))
    return records


def load_enron_spam(path: Path) -> List[Record]:
    """CSV (optionally zipped) with columns Subject, Message, Spam/Ham."""
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as archive:
            names = [n for n in archive.namelist() if n.lower().endswith(".csv")]
            if not names:
                raise ValueError(f"No CSV found inside {path}")
            raw = archive.read(names[0])
        handle = io.StringIO(raw.decode("utf-8", errors="replace"), newline="")
    else:
        handle = open(path, "r", encoding="utf-8", errors="replace", newline="")
    records: List[Record] = []
    with handle:
        reader = csv.DictReader(handle)
        for row in reader:
            label = (row.get("Spam/Ham") or "").strip().lower()
            if label not in {"spam", "ham"}:
                continue
            subject = (row.get("Subject") or "").strip()
            body = (row.get("Message") or "").strip()
            text = f"{subject}\n{body}".strip()
            records.append(Record(text=text, label=1 if label == "spam" else 0, source="enron_spam"))
    return records


def load_phishing_email_hf(path: Path) -> List[Record]:
    """Hugging Face CSV; expected columns 'Email Text' and 'Email Type' (Safe/Phishing Email)."""
    records: List[Record] = []
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = {(f or "").strip().lower(): f for f in (reader.fieldnames or [])}
        text_col = next((fields[k] for k in ("email text", "text", "body", "email") if k in fields), None)
        label_col = next((fields[k] for k in ("email type", "label", "class", "type") if k in fields), None)
        if not text_col or not label_col:
            raise ValueError(f"Unrecognised columns in {path}: {reader.fieldnames}")
        unknown = Counter()
        for row in reader:
            text = (row.get(text_col) or "").strip()
            label = (row.get(label_col) or "").strip().lower()
            if not text or text == "empty":
                continue
            if label in {"phishing email", "phishing", "1", "spam"}:
                records.append(Record(text, 1, "phishing_email_hf"))
            elif label in {"safe email", "safe", "legitimate", "ham", "0"}:
                records.append(Record(text, 0, "phishing_email_hf"))
            else:
                unknown[label] += 1
        if unknown:
            print(f"[data] WARNING: ignored rows with unrecognised labels in {path.name}: {dict(unknown)}")
    return records


_LOADERS = {"uci_sms": load_uci_sms, "enron_spam": load_enron_spam, "phishing_email_hf": load_phishing_email_hf}


def find_raw_file(raw_dir: Path, source: str) -> Optional[Path]:
    for rel in RAW_FILES[source]:
        candidate = raw_dir / rel
        if candidate.is_file():
            return candidate
    return None


def load_sources(raw_dir: Path, wanted: Optional[Sequence[str]] = None) -> Tuple[List[Record], Dict[str, dict]]:
    """Load every available source. Returns (records, per-source loading report)."""
    records: List[Record] = []
    report: Dict[str, dict] = {}
    for source in (wanted or list(SOURCES)):
        path = find_raw_file(raw_dir, source)
        if path is None:
            report[source] = {"status": "not_downloaded", "records": 0}
            continue
        loaded = _LOADERS[source](path)
        records.extend(loaded)
        report[source] = {"status": "loaded", "file": path.name, "records": len(loaded),
                          "positives": sum(r.label for r in loaded)}
    return records, report


# --------------------------------------------------------------------------- cleaning
def clean_and_dedupe(records: Sequence[Record], max_tokens: int = 256, min_tokens: int = 3
                     ) -> Tuple[List[Record], List[List[str]], dict]:
    """Tokenise, drop too-short texts, drop exact duplicates and label conflicts.

    De-duplication runs BEFORE splitting so identical messages can never sit in both
    the training and the test set (a common cause of inflated accuracy).
    """
    seen: Dict[str, Tuple[int, int]] = {}  # key -> (label, index in kept)
    conflicts = set()
    kept: List[Record] = []
    kept_tokens: List[List[str]] = []
    dropped_short = dropped_dup = 0
    for rec in records:
        toks = tokenize(rec.text, max_tokens)
        if len(toks) < min_tokens:
            dropped_short += 1
            continue
        key = tokens_to_text(toks)
        if key in seen:
            if seen[key][0] != rec.label:
                conflicts.add(key)
            dropped_dup += 1
            continue
        seen[key] = (rec.label, len(kept))
        kept.append(rec)
        kept_tokens.append(toks)
    if conflicts:
        keep_idx = [i for i, toks in enumerate(kept_tokens) if tokens_to_text(toks) not in conflicts]
        kept = [kept[i] for i in keep_idx]
        kept_tokens = [kept_tokens[i] for i in keep_idx]
    report = {"input_records": len(records), "dropped_too_short": dropped_short,
              "dropped_exact_duplicates": dropped_dup, "dropped_label_conflicts": len(conflicts),
              "records_after_cleaning": len(kept)}
    return kept, kept_tokens, report


# --------------------------------------------------------------------------- splitting
def stratified_split(records: Sequence[Record], seed: int = 42, val_frac: float = 0.1, test_frac: float = 0.1
                     ) -> Dict[str, np.ndarray]:
    """Stratify on (source, label) so every split keeps each source's class balance."""
    rng = np.random.default_rng(seed)
    strata: Dict[Tuple[str, int], List[int]] = defaultdict(list)
    for i, rec in enumerate(records):
        strata[(rec.source, rec.label)].append(i)
    out: Dict[str, List[int]] = {"train": [], "val": [], "test": []}
    for key in sorted(strata):
        idx = np.array(strata[key])
        rng.shuffle(idx)
        n_test = int(round(len(idx) * test_frac))
        n_val = int(round(len(idx) * val_frac))
        out["test"].extend(idx[:n_test].tolist())
        out["val"].extend(idx[n_test:n_test + n_val].tolist())
        out["train"].extend(idx[n_test + n_val:].tolist())
    return {k: np.array(sorted(v)) for k, v in out.items()}


def dataset_report(records: Sequence[Record], splits: Dict[str, np.ndarray], loading: dict, cleaning: dict,
                   seed: int) -> dict:
    """Machine-readable summary stored next to the model and shown in the UI."""
    per_split: Dict[str, dict] = {}
    for name, idx in splits.items():
        by_source: Dict[str, Dict[str, int]] = defaultdict(lambda: {"legitimate": 0, "malicious": 0})
        for i in idx:
            by_source[records[i].source]["malicious" if records[i].label else "legitimate"] += 1
        per_split[name] = {"total": int(len(idx)), "malicious": int(sum(records[i].label for i in idx)),
                           "by_source": {k: dict(v) for k, v in by_source.items()}}
    return {"seed": seed, "sources": {k: {**SOURCES[k], **loading.get(k, {})} for k in SOURCES},
            "cleaning": cleaning, "splits": per_split,
            "preprocessing": ("NFKC normalisation, HTML-tag removal, lower-casing, URL/e-mail/phone/number placeholders, "
                              "regex word tokenisation, first 256 tokens kept. Exact duplicates and label conflicts removed "
                              "before splitting. Vocabulary built from the training split only.")}
