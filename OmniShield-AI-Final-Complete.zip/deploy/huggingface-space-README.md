---
title: OmniShield AI
emoji: 🛡️
colorFrom: gray
colorTo: gray
sdk: docker
app_port: 7860
pinned: false
---

# OmniShield AI

Defensive phishing / spam, data-leak, invoice and prompt-injection triage demo.
Open `/demo` for the dashboard, `/docs` for the API, `/api/v1/model/info` for model metrics.
Synthetic demo only: a clean result is not proof of safety.
