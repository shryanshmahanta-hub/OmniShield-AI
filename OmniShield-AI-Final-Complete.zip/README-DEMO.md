# OmniShield AI - demo status and commands

## Windows (PowerShell), from the project root

```powershell
.\train.ps1                 # venv + deps + datasets + train PyTorch TextCNN & baseline + tests (10-30 min on CPU)
.\train.ps1 -BaselineOnly   # no PyTorch needed, ~10 s
.\run.ps1                   # http://127.0.0.1:8000/demo   (Model Metrics page shows the measured numbers)
```
If PowerShell blocks scripts: `powershell -ExecutionPolicy Bypass -File .\train.ps1`.

Manual equivalent:

```powershell
cd omnishield-backend
py -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements-train.txt
python scripts/download_datasets.py --all-text
python scripts/train_model.py     # artifacts/phishing/MODEL_CARD.md has the metrics
Copy-Item .env.example .env
$env:RATE_LIMIT_PER_MINUTE="0"; uvicorn app.main:app --host 127.0.0.1 --port 8000
pytest -q
```

Endpoints: `/demo` (UI), `/docs`, `/api/v1/model/info`, `/api/v1/stats`.
Deploying for judges: see `DEPLOYMENT.md` (Hugging Face Spaces, Docker).

## Status

| Area | State |
|---|---|
| Datasets, cleaning, split, TF-IDF baseline, API inference | Run and measured (see `artifacts/phishing/`) |
| PyTorch TextCNN | Code written and reviewed, **never executed yet**: run `train.ps1` and read the real metrics |
| Dashboard: probability, word impacts, overview cards from `/api/v1/stats`, Model Metrics page | Done; rendered and checked in headless Chromium against mocked API data |
| Extra prompt-injection patterns | Done (`app/services/injection_detector.py`) |
| New tests (`test_injection_patterns`, `test_local_model`, `test_stats`) | Written; see TEST-REPORT.md for what was executed where |
| Dockerfile + `.dockerignore` + HF Space template | Written; **not built** (no Docker in the authoring sandbox) |
| `train.ps1` / `run.ps1` | Written; **not executed** (no PowerShell in the authoring sandbox) |
