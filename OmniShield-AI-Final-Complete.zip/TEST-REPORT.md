# OmniShield AI release verification report

Run date: 2026-10-15

## Automated checks

- Command: `python -m pytest -q` (working directory: `omnishield-backend/`)
- Result: **116 passed, 1 skipped**.
- JavaScript syntax: `node --check` run against all 3 inline script blocks in `frontend-demo/index.html`; **all passed**.
- Route contract: automated test checks the primary dashboard scan, AI-status, history, and PWA paths against registered FastAPI routes.
- PWA smoke tests: `/demo`, `/manifest.webmanifest`, `/service-worker.js`, and both icon endpoints returned HTTP 200 under the test client.
- Secret-pattern scan: no matching common hard-coded token patterns found in backend Python source.

## Important scope notes

- The reported historical `Request failed (404)` could not be reproduced exactly because the original browser Network request URL/method was not supplied. In this source snapshot the primary frontend API paths match registered routes. The frontend now reports method + full request URL, provides status-specific guidance, and normalizes common `/api` or `/api/v1` suffixes in the configured base URL.
- One existing test remains skipped; it was not converted into a pass.
- Optional model weights and third-party credentials are not included. Models remain disabled unless explicitly configured and available locally.
- PDF invoice text extraction is not implemented in this bundle; invoice checking operates on structured fields. Do not represent the structured-field workflow as PDF/OCR support.
- QR image decoding depends on the optional QR dependencies. Threat-intelligence absence does not imply a destination is safe.
- This is a hackathon/demo foundation, not a production guarantee of malware or fraud detection. Review authentication, persistence, CORS, and model provenance before deployment.


---

## Update: second-pass changes (model integration, UI, injection patterns, deployment)

The section above describes an earlier snapshot. For this revision, what was **actually executed**, and where:

| Check | Result | Where |
|---|---|---|
| `tests/test_injection_patterns.py` (31 cases: 15 attack variants, 11 benign guards, obfuscation, table sanity) | 31 passed | authoring sandbox, run through a minimal pytest stand-in with `pydantic` stubbed (module import only) |
| `tests/test_local_model.py`, model-level tests (12) against the shipped baseline artifacts | 12 passed | same |
| `tests/test_local_model.py`, 2 HTTP tests (`/scan/message`, `/scan/email`) | **not run** | need FastAPI; not installable offline |
| `tests/test_stats.py` (4 tests) | **not run** | need FastAPI |
| `tests/test_frontend_route_contract.py` (extended with `/api/v1/stats`, `/api/v1/model/info`) | **not run** | need FastAPI |
| Existing suite (114 previously passing) after the detector change | **not re-run** | need FastAPI |
| Dashboard in headless Chromium against mocked API data (overview cards, probability bar, word impacts, Model Metrics page, 390 px mobile width) | rendered, 0 console errors, no horizontal scroll | authoring sandbox |
| `node --check` on all 3 inline scripts | passed | authoring sandbox |
| PyTorch TextCNN training/inference | **never executed** (static review only) | - |
| `Dockerfile` build, `train.ps1`, `run.ps1` | **never executed** | no Docker / PowerShell available |

Please run `pytest -q` on your machine; that run is the authoritative result for this revision.

Behaviour change to be aware of: `detect_injection` now NFKC-normalises text and strips zero-width characters before
matching and has 12 more patterns. The two false positives found while tuning (a "developer mode" how-to question and a
plain "forward the notes to <email>") were fixed and are pinned by tests; other benign phrasings may still trigger rules.
