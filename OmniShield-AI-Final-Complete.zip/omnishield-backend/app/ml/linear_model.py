"""TF-IDF + logistic-regression BASELINE, exported to plain JSON.

This is a classical (non-deep-learning) benchmark. It is trained on exactly the same
splits as the deep model so the comparison is fair, and it doubles as an honestly
labelled fallback when PyTorch is unavailable. Weights are stored as JSON and scored by
a tiny pure-Python implementation, so there is no pickle (no code execution on load) and
no scikit-learn version coupling at serve time.
"""
from __future__ import annotations

import json
import math
from collections import Counter
from pathlib import Path
from typing import Dict, List, Sequence


def fit_baseline(train_token_lists: Sequence[Sequence[str]], y_train: Sequence[int], *, max_features: int = 100000,
                 C: float = 4.0, seed: int = 42) -> dict:
    """Fit with scikit-learn and return a JSON-serialisable parameter dict."""
    import numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression

    docs = [" ".join(t) for t in train_token_lists]
    vec = TfidfVectorizer(tokenizer=str.split, token_pattern=None, lowercase=False, ngram_range=(1, 2),
                          min_df=2, max_features=max_features, sublinear_tf=True, norm="l2", dtype=np.float64)
    X = vec.fit_transform(docs)
    clf = LogisticRegression(C=C, max_iter=2000, solver="liblinear", random_state=seed)
    clf.fit(X, list(y_train))
    return {"vocab": {k: int(v) for k, v in vec.vocabulary_.items()}, "idf": [float(x) for x in vec.idf_],
            "coef": [float(x) for x in clf.coef_[0]], "intercept": float(clf.intercept_[0]),
            "ngram_range": [1, 2], "C": C}


class TfidfLogReg:
    """Pure-Python scorer reproducing scikit-learn's TfidfVectorizer(sublinear_tf) + LogisticRegression."""

    def __init__(self, params: dict):
        self.vocab: Dict[str, int] = params["vocab"]
        self.idf: List[float] = params["idf"]
        self.coef: List[float] = params["coef"]
        self.intercept: float = float(params["intercept"])

    def _features(self, tokens: Sequence[str]) -> Dict[int, float]:
        grams = list(tokens) + [f"{a} {b}" for a, b in zip(tokens, tokens[1:])]
        counts = Counter(g for g in grams if g in self.vocab)
        feats = {self.vocab[g]: (1.0 + math.log(c)) * self.idf[self.vocab[g]] for g, c in counts.items()}
        norm = math.sqrt(sum(v * v for v in feats.values()))
        return {k: v / norm for k, v in feats.items()} if norm > 0 else {}

    def predict_proba_tokens(self, token_lists: Sequence[Sequence[str]]) -> List[float]:
        out = []
        for toks in token_lists:
            z = self.intercept + sum(self.coef[i] * v for i, v in self._features(toks).items())
            out.append(1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, z)))))
        return out


def save_params(params: dict, path: Path) -> None:
    path.write_text(json.dumps(params, separators=(",", ":")), encoding="utf-8")


def load_params(path: Path) -> TfidfLogReg:
    return TfidfLogReg(json.loads(path.read_text(encoding="utf-8")))
