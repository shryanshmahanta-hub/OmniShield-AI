// Vercel build step: writes config.js from the API_BASE_URL environment variable.
import { writeFileSync } from "node:fs";
const base = (process.env.API_BASE_URL || "").trim().replace(/\/+$/, "");
if (!base) console.warn("WARNING: API_BASE_URL is not set - the site will call its own origin and scans will fail on Vercel.");
writeFileSync(new URL("./config.js", import.meta.url), `window.OMNISHIELD_CONFIG = ${JSON.stringify({ API_BASE_URL: base })};\n`);
console.log("config.js written, API_BASE_URL =", base || "(empty)");
