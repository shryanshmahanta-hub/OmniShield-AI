"""OmniShield local text-classification pipeline (training + inference).

Nothing in this package imports PyTorch at import time. Torch is imported lazily by
``torch_model`` / ``train_torch`` / the inference loader, so the API can start (and
report honest model status) on machines where PyTorch is not installed.
"""
